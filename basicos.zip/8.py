num1 = int(input("Numero 1: "))
num2 = int(input("Numero 2: "))
print(num1+ num2 + int(input("Numero 3: ")))