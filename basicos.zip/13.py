num1 = int(input("Introduce un número entero: "))
num2 = int(input("Introduce otro número entero: "))
print(f"La división de {num1} entre {num2} da un cociente {num1/num2} y un resto {num1 % num2}",)