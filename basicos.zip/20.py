tel = input("Numero de tel: ")
print(tel.split("-")[1])