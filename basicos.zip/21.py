frase = input("Frase: ")
print("Frase invertida:", frase[::-1])