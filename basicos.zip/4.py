celsius = int(input("Introduce grados celsius: "))
print(celsius*1.8+32, "grados Fahrenheit")