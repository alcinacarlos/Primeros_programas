nombre = input("Ingresa tu nombre: ")
numero = int(input("Ingresa un número entero: "))
for i in range(numero):
    print(nombre)