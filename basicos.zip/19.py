nombre = input("Ingresa tu nombre: ")
numero_letras = len(nombre)
mayusculas = nombre.upper()
print(mayusculas, "tiene", numero_letras, "letras.")