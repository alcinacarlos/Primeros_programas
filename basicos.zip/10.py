resultado = ((3+2)/(2*5))**2
print(resultado)