num_payasos = int(input("Ingrese el número de payasos vendidos: "))
num_muñecas = int(input("Ingrese el número de muñecas vendidas: "))
total = num_payasos * 112 + num_muñecas * 75
print(f"Peso total del paquete: {total} gr.")