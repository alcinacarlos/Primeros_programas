ancho = 17
alto = 12.0

#ancho/2 = 8.5, ancho//2 = 8, alto/3 = 4.0, 1+2*5= 11
print(ancho/2)
print(ancho // 2)
print(alto/3)
print(1 +2 *5)