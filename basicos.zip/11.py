n = int(input("Introduce un número entero: "))
suma = (n*(n+1))/2
print(f"La suma de todos los enteros desde 1 hasta {n} es: {suma}")