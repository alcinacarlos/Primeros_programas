horas = int(input("Horas de trabajo: "))
coste = int(input("Coste por hora: "))
print("Importe total:", horas*coste)